package coursetracking;

import coursetracking.utils.ControlCenter;


/**
 * App
 */
public class App {

  
    public static void main(String[] args) throws Exception {
        ControlCenter ControlCenter = new ControlCenter();
        ControlCenter.start();
    }
}

